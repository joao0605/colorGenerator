import { Paleta } from './components/Paleta';
import './App.css';

function App() {
  return (
    <div className="App">
      <Paleta />
   
    </div>
  );
}

export default App;
